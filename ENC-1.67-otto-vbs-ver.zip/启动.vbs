﻿' ENcwork 启动器：用 Edge/Chrome 的“应用窗口”模式打开同目录的 index.html（无窗口边框、像原生程序）
Option Explicit
Dim fso, shell, here, target, browser, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
here = fso.GetParentFolderName(WScript.ScriptFullName)
target = here & "\index.html"
If Not fso.FileExists(target) Then
  MsgBox "找不到 index.html，请把本脚本与 index.html 放在同一个文件夹里。", 48, "ENcwork"
  WScript.Quit
End If
' 依次尝试 Edge、Chrome（用户数据目录独立，避免污染日常浏览器配置）
browser = ""
If fso.FileExists(shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe") Then
  browser = shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Microsoft\Edge\Application\msedge.exe"
ElseIf fso.FileExists(shell.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe") Then
  browser = shell.ExpandEnvironmentStrings("%ProgramFiles%") & "\Microsoft\Edge\Application\msedge.exe"
ElseIf fso.FileExists(shell.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe") Then
  browser = shell.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe"
ElseIf fso.FileExists(shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe") Then
  browser = shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe"
End If
If browser = "" Then
  ' 没有 Edge/Chrome：交给系统默认浏览器
  shell.Run "explorer.exe """ & target & """", 1, False
  WScript.Quit
End If
cmd = """" & browser & """ --app=""file:///" & Replace(target, "\", "/") & """ --user-data-dir=""" & here & "\.encprofile"" --start-maximized"
shell.Run cmd, 1, False
