Option Explicit

' ============================================================
'  ENcwork 静默启动 / 关闭器
'  双击启动；再双击一次 → 关闭
'  全程无弹窗、无命令行窗口
'  兼容 Win7 / 8.1 / 10 / 11
'  兼容 Edge / Chrome / 360 / QQ / 搜狗 / 猎豹 / 2345 等
' ============================================================

Dim FLAG
FLAG = "ENcworkUniqueFlag_9F3A7B"

Dim fso, shell, scriptDir, htmlFile, appDataDir
Set fso   = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

scriptDir  = fso.GetParentFolderName(WScript.ScriptFullName)
htmlFile   = scriptDir & "\index.html"
appDataDir = shell.ExpandEnvironmentStrings("%TEMP%") & "\" & FLAG

' ---------- 1. 检查 index.html（不存在则静默退出）----------
If Not fso.FileExists(htmlFile) Then
    WScript.Quit 1
End If

' ---------- 2. 查询所有浏览器进程 ----------
Dim wmi, q, procs
Set wmi = GetObject("winmgmts:\\.\root\cimv2")

q = "SELECT ProcessId, Name, CommandLine FROM Win32_Process WHERE " & _
    "Name='msedge.exe' OR Name='chrome.exe' OR " & _
    "Name='360se.exe' OR Name='360se6.exe' OR Name='360Chrome.exe' OR " & _
    "Name='360ChromeX.exe' OR Name='360Browser.exe' OR " & _
    "Name='360SeSP.exe' OR Name='360SPB.exe' OR " & _
    "Name='QQBrowser.exe' OR Name='SogouExplorer.exe' OR " & _
    "Name='Liebao.exe' OR Name='2345Explorer.exe' OR " & _
    "Name='2345chrome.exe' OR Name='2345Mini.exe' OR " & _
    "Name='TheWorld.exe' OR Name='UCBrowser.exe' OR " & _
    "Name='Maxthon.exe' OR Name='BaiduBrowser.exe' OR " & _
    "Name='115Browser.exe'"

Set procs = wmi.ExecQuery(q)

' ---------- 3. 找出属于本应用的进程 ----------
Dim targetIds, count, p
targetIds = ""
count = 0

For Each p In procs
    Dim cl
    cl = ""
    On Error Resume Next
    cl = p.CommandLine
    If Err.Number <> 0 Then cl = ""
    Err.Clear
    On Error GoTo 0

    If Len(cl) > 0 Then
        If InStr(1, cl, FLAG, vbTextCompare) > 0 Then
            count = count + 1
            targetIds = targetIds & p.ProcessId & ","
        End If
    End If
Next

' ---------- 4. 若已运行 → 静默关闭 ----------
If count > 0 Then
    Dim arr, i
    arr = Split(targetIds, ",")
    For i = 0 To UBound(arr)
        If Len(arr(i)) > 0 Then
            On Error Resume Next
            Dim proc, pp
            Set proc = wmi.ExecQuery("SELECT * FROM Win32_Process WHERE ProcessId=" & arr(i))
            For Each pp In proc
                pp.Terminate()
            Next
            Err.Clear
            On Error GoTo 0
        End If
    Next

    WScript.Sleep 300

    For i = 0 To UBound(arr)
        If Len(arr(i)) > 0 Then
            shell.Run "taskkill /F /PID " & arr(i), 0, True
        End If
    Next
    WScript.Quit 0
End If

' ---------- 5. 查找可用浏览器 ----------
Dim pf, pf86, lad
pf   = shell.ExpandEnvironmentStrings("%ProgramFiles%")
pf86 = shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%")
lad  = shell.ExpandEnvironmentStrings("%LocalAppData%")

Dim candidates, path
candidates = Array( _
    pf86 & "\Microsoft\Edge\Application\msedge.exe", _
    pf   & "\Microsoft\Edge\Application\msedge.exe", _
    pf   & "\Google\Chrome\Application\chrome.exe", _
    pf86 & "\Google\Chrome\Application\chrome.exe", _
    lad  & "\Google\Chrome\Application\chrome.exe", _
    pf86 & "\360\360se6\Application\360se.exe", _
    pf   & "\360\360se6\Application\360se.exe", _
    pf86 & "\360\360se\Application\360se.exe", _
    pf   & "\360\360se\Application\360se.exe", _
    pf86 & "\360Chrome\Chrome\Application\360chrome.exe", _
    pf   & "\360Chrome\Chrome\Application\360chrome.exe", _
    lad  & "\360Chrome\Chrome\Application\360chrome.exe", _
    lad  & "\360ChromeX\Chrome\Application\360ChromeX.exe", _
    pf86 & "\Tencent\QQBrowser\QQBrowser.exe", _
    pf   & "\Tencent\QQBrowser\QQBrowser.exe", _
    pf86 & "\SogouExplorer\SogouExplorer.exe", _
    pf   & "\SogouExplorer\SogouExplorer.exe", _
    pf86 & "\Liebao\Liebao.exe", _
    pf   & "\Liebao\Liebao.exe", _
    pf86 & "\2345Explorer\2345Explorer.exe", _
    pf   & "\2345Explorer\2345Explorer.exe", _
    pf86 & "\TheWorld6\Application\TheWorld.exe", _
    pf86 & "\Maxthon\Bin\Maxthon.exe", _
    pf86 & "\Baidu\BaiduBrowser\BaiduBrowser.exe", _
    pf86 & "\115Chrome\Application\115chrome.exe" _
)

Dim browserPath
browserPath = ""
For Each path In candidates
    If fso.FileExists(path) Then
        browserPath = path
        Exit For
    End If
Next

' 没找到浏览器 → 静默退出
If browserPath = "" Then
    WScript.Quit 1
End If

' ---------- 6. 静默启动独立窗口 ----------
Dim url, args
url = "file:///" & Replace(htmlFile, "\", "/")

args = "--app=""" & url & """" & " " & _
       "--user-data-dir=""" & appDataDir & "\" & FLAG & """" & " " & _
       "--window-size=1280,860 " & _
       "--no-first-run --no-default-browser-check " & _
       "--disable-features=Translate,msEdgeTranslate"

shell.Run """" & browserPath & """ " & args, 1, False